-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: zebra
-- ------------------------------------------------------
-- Server version	5.7.12-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `reviewtb`
--

DROP TABLE IF EXISTS `reviewtb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reviewtb` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `id` varchar(45) NOT NULL,
  `barcode` varchar(45) NOT NULL,
  `reviewText` longtext NOT NULL,
  `starPoint` double NOT NULL,
  `memberUrl` longtext NOT NULL,
  `productUrl` longtext NOT NULL,
  PRIMARY KEY (`index`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviewtb`
--

LOCK TABLES `reviewtb` WRITE;
/*!40000 ALTER TABLE `reviewtb` DISABLE KEYS */;
INSERT INTO `reviewtb` VALUES (1,'alice823','103','스프링 사용만 하다가 심층적으로 공부하기 위해 샀는데, 좋네요!!',4,'http://a',''),(2,'trycry','103','스프링에 관해서 가장 유명한 책 중의 하나 인것 같습니다. 상세히 기술 되어 있는 내용이 혼자서 독학하시는 분들께 매우 유용할 것으로 생각되네요 ',4,'http://a',''),(3,'luckrock','103','책이 두꺼운만큼 많은 내용이 들어있어서 좋네요. 단순히 스프링에 대한 책이라기보다는 자바의 대한 전반적인 지식을 차례대로 소개시켜주는 느낌입니다. ',3,'http://b',''),(4,'ultra','103','소프트웨어개발을 전공하는 자로서 객체지향기법의 소프트웨어 개발에 관한 비젼을 얻었다',5,'http://b',''),(5,'hot8118','103','너무 상세히 자세히 설명되어있어서 이해부터 구현까지 굉장히 도움이 많이 되는 책입니다. ',4.5,'https://scontent.xx.fbcdn.net/v/t1.0-9/13133331_159272791137480_2076198251917202711_n.jpg?oh=0ff3e11adaa947acfd481819011865c8&oe=57E2D8BF',''),(6,'limky8118','8801056049881','흡입력이 좋은데도 불구하고 소음이 적어서 굉장히 놀랐습니다~',4.6,'https://scontent.xx.fbcdn.net/v/t1.0-9/13321921_177022146029211_9105196508368089817_n.jpg?oh=123f561c9d448ef1d90f4243fb4dbd4a&oe=57E321F4',''),(7,'b','841456049881','안드로이드 통신 테스트 3',2,'http://b',''),(30,'a','9842156','냄세가 참좋네요',4,'http://a','http://www.dior.com/beauty/version-5.1432748111895/resize-image/ep/0/390/100/0/v6_packshots_pdg%252FPDG_Y0578850-F057885020.jpg'),(31,'b','9842156','디올이라그런지 쩌네요',3,'http://b','http://www.dior.com/beauty/version-5.1432748111895/resize-image/ep/0/390/100/0/v6_packshots_pdg%252FPDG_Y0578850-F057885020.jpg'),(32,'bung56','8801056059842','목넘김이 부드럽고 깔끔해서 좋아요!',1,'h','h'),(33,'inhyuck111','8801056059842','각종 회의나 세미나에서 많이 활용중입니다!',1,'h','h'),(34,'a','8801056059842','dd',2,'Http://에이','http://www.dior.com/beauty/version-5.1432748111895/resize-image/ep/0/390/100/0/v6_packshots_pdg%252FPDG_Y0578850-F057885020.jpg'),(35,'a','8801056059842','dee',2,'Http://에이','http://www.dior.com/beauty/version-5.1432748111895/resize-image/ep/0/390/100/0/v6_packshots_pdg%252FPDG_Y0578850-F057885020.jpg'),(36,'a','8801056049881','맛있어요',2,'Http://에이','http://www.dior.com/beauty/version-5.1432748111895/resize-image/ep/0/390/100/0/v6_packshots_pdg%252FPDG_Y0578850-F057885020.jpg'),(37,'a','8801056049881','목넘김이 부드럽고 깔끔해서 좋아요!',3,'a','d'),(38,'a','8801056049881','목넘김이 부드럽고 깔끔해서 좋아요!목넘김이 부드럽고 깔끔해서 좋아요!',3,'b','d'),(39,'a','8801056049881','목넘김이 부드럽고 깔끔해서 좋아요!',3,'d','d'),(40,'a','8801056049881','맛있어요맛있어요',3,'d','d'),(41,'a','8801056059842','g',4,'d','d'),(42,'a','8801056059842','g',4,'d','d'),(43,'a','8801056059842','h',4,'d','d'),(44,'a','8801056059842','j',4,'d','d'),(45,'a','8801056059842','re',4,'d','d'),(46,'a','8801056059842','w',5,'d','d');
/*!40000 ALTER TABLE `reviewtb` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-05-27 22:38:28
